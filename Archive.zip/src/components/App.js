// import logo from './logo.svg';
// import './App.css';
import { Route, Switch} from 'react-router-dom';
import moviesList from './moviesList';



showListHandler = () => {
  this.history.push('/moviesList');
}



function App() {
  return (
    <div >
      <Switch>
        <Route path = '/moviesList' components = {moviesList}/>
        <Route path='/' exact components = {App}/>

      </Switch>

      <moviesList showMovieList = {this.showListHandler}/>
    
    </div>
  );
}

export default App;
