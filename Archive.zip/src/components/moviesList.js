import React from 'react';
import { connect} from 'react-redux';
import { fetchMovies } from '../actions';



class moviesList extends React.Component {
    componentDidMount() {
        this.props.fetchMovies();
    }
    renderList() {
        return this.props.posts.map(post => {
            return (
                <div key={post.id}>
                    <div>
                        <h2>{post.title}</h2>
                        <p>{post.description}</p>
                    </div>
                    <button clicked = {this.props.showMovieList}/>
                </div>
            )

        })

        }
        render() {
            return <div>{this.moviesList()}</div>
        }
}

const mapstateToProps = (state) => {
    return { posts: state.posts};
}

export default connect(null, { fetchMovies })(moviestList);