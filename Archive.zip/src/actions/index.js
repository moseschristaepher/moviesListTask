import jsonPlaceholder from "../apis/jsonPlaceholder";



export const fetchMovies = () => async dispatch => {
    const response = await jsonPlaceholder.get('StreamCo/react-coding-challenge/master/feed/sample.json');
    // return {
    //     type: 'FETCH_POSTS'
    // }
    dispatch({ type: 'FETCH_MOVIES' , payload: response})
};